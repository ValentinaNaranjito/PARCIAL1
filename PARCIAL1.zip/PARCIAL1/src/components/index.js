class perfil extends HTMLElement{
    components (){
        [¨destino¨,¨duracion¨,¨costo¨,¨descripcion¨,¨actividades¨,¨¨]
}
    }
    